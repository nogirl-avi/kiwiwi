import { promises as fs } from "node:fs";
import { glob } from "glob";

function parseFrontMatter(text) {
  if (!text.startsWith('---')) return {};
  const end = text.indexOf('\n---', 3);
  if (end === -1) return {};
  const yaml = text.slice(3, end).trim();
  const fm = {};
  yaml.split('\n').forEach(line => {
    const m = line.match(/^(\w+):\s*(.*)$/);
    if (m) {
      const k = m[1];
      let v = m[2].trim();
      v = v.replace(/^"|"$/g, '');
      fm[k] = v;
    }
  });
  return fm;
}

const files = await glob("diary/*/*.html");
const map = {};
for (const path of files) {
  const m = path.match(/diary\/(\d{4})\/(\d{8})\.html$/);
  if (!m) continue;
  const [, yyyy, yyyymmdd] = m;
  const key = `${yyyy}-${yyyymmdd.slice(4,6)}-${yyyymmdd.slice(6,8)}`;
  const raw = await fs.readFile(path, "utf8").catch(()=> "");
  const fm = parseFrontMatter(raw);
  map[key] = { url: path, title: fm.title || "" };
}

await fs.mkdir("data", { recursive: true });
await fs.writeFile("data/diary-index.json", JSON.stringify(map, null, 2));
console.log("index entries:", Object.keys(map).length);
